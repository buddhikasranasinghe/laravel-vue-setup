<template>
    <div>
        <div>
            <router-view></router-view>
        </div>
    </div>
</template>