@extends('layouts.topnav')

@section('content')
{{-- <div class="container"> --}}
    {{-- <div class="card"> --}}
        {{-- <div class="card-body"> --}}
            <user-app></user-app>
        {{-- </div>
    </div>
</div> --}}
@endsection
