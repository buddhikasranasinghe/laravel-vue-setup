@extends('welcome')

@section('landingpage')
    
@endsection